import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import InstallmentManagement from "./components/InstallmentManagement";

const App = () => {
  return (
    <div>
      <InstallmentManagement />
    </div>
  );
};

export default App;
